package application;

public class Skiier {

}
