package application;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			GridPane myGrid = new GridPane();
			myGrid.setAlignment(Pos.TOP_CENTER);
			myGrid.setHgap(40);
			myGrid.setVgap(30);

			Text banner = new Text("Welcome to the stopwatch!");
			banner.setFont(Font.font("Edwardian Script ITC", FontWeight.BOLD, 40));
			banner.setStroke(Color.RED);
			banner.setFill(Color.BLACK);
			banner.setUnderline(true);

			Button massStart = new Button("Masstart");
			massStart.setPrefSize(150, 40);
			massStart.setOnAction(e -> {

			});
			Button jaktStart = new Button("Jaktstart");
			jaktStart.setPrefSize(150, 40);
			jaktStart.setOnAction(e -> {

			});
			Button intStart = new Button("Intervallstart");
			intStart.setPrefSize(150, 40);
			intStart.setOnAction(e -> {

			});

			myGrid.add(banner, 1, 1);
			myGrid.add(intStart, 1, 2);
			myGrid.add(jaktStart, 1, 3);
			myGrid.add(massStart, 1, 4);

			Scene scene = new Scene(myGrid);
			primaryStage.setWidth(500);
			primaryStage.setHeight(400);
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}